﻿using System;
using System.Collections.Generic;

namespace BackEnd.Entities;

public partial class Dangkysach
{
    public int Iddangkysach { get; set; }

    public string Madangkysach { get; set; } = null!;

    public int Soluongsach { get; set; }

    public string Tentacgia { get; set; } = null!;

    public string? Theloai { get; set; }

    public DateTime Ngayxuatban { get; set; }

    public virtual Sach MadangkysachNavigation { get; set; } = null!;
}
