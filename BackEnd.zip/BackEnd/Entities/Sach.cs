﻿using System;
using System.Collections.Generic;

namespace BackEnd.Entities;

public partial class Sach
{
    public string Sach1 { get; set; } = null!;

    public string Nhaxuatban { get; set; } = null!;

    public string Tensach { get; set; } = null!;

    public string Sotrang { get; set; } = null!;

    public string ? Tinhtrang  { get; set; }

    public virtual ICollection<Dangkysach> Dangkysaches { get; set; } = new List<Dangkysach>();
}
