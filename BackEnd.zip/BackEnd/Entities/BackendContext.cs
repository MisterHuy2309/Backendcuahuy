﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BackEnd.Entities;

public partial class BackendContext : DbContext
{
    public BackendContext()
    {    
    }

    public BackendContext(DbContextOptions<BackendContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Dangkysach> Dangkysaches { get; set; }

    public virtual DbSet<Sach> Saches { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source= DESKTOP-D95B98Q\\SQLEXPRESS; Initial Catalog=Backend; Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Dangkysach>(entity =>
        {
            entity.HasKey(e => e.Iddangkysach).HasName("PK__DANGKYSA__93C49581C97DA477");

            entity.ToTable("DANGKYSACH");

            entity.Property(e => e.Iddangkysach)
                .ValueGeneratedNever()
                .HasColumnName("IDDANGKYSACH");
            entity.Property(e => e.Madangkysach)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("MADANGKYSACH");
            entity.Property(e => e.Ngayxuatban)
                .HasColumnType("date")
                .HasColumnName("NGAYXUATBAN");
            entity.Property(e => e.Soluongsach).HasColumnName("SOLUONGSACH");
            entity.Property(e => e.Tentacgia)
                .HasMaxLength(100)
                .HasColumnName("TENTACGIA");
            entity.Property(e => e.Theloai)
                .HasMaxLength(100)
                .HasColumnName("THELOAI");

            entity.HasOne(d => d.MadangkysachNavigation).WithMany(p => p.Dangkysaches)
                .HasForeignKey(d => d.Madangkysach)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DANGKYSACH");
        });

        modelBuilder.Entity<Sach>(entity =>
        {
            entity.HasKey(e => e.Sach1).HasName("PK__SACH__8895FBCAB15EABA2");

            entity.ToTable("SACH");

            entity.Property(e => e.Sach1)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("SACH");
            entity.Property(e => e.Nhaxuatban)
                .HasMaxLength(100)
                .HasColumnName("NHAXUATBAN");
            entity.Property(e => e.Sotrang)
                .HasMaxLength(100)
                .HasColumnName("SOTRANG");
            entity.Property(e => e.Tensach)
                .HasMaxLength(100)
                .HasColumnName("TENSACH");
            entity.Property(e => e.Tinhtrang)
                .HasMaxLength(100)
                .HasDefaultValueSql("(N'CHUA CO AI THUE')")
                .HasColumnName("TINHTRANG");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
