using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using BackEnd.Entities;
using BackEnd.Models;
using System.Net;
namespace BackEnd.Controllers
{
[ApiController]
[Route("api/[controller]")]
  
    public class SachController : ControllerBase
    {
        private readonly BackendContext _context; 
        public SachController(BackendContext context) 
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Sach>>> GetAllSach()
        {
            var sachList = await _context.Saches.ToListAsync();

            if (sachList == null || sachList.Count == 0)
            {
                return NotFound();
            }

            return sachList;
        }
        [HttpGet("search")]// tim ma dang ky sach gan dung
        public async Task<ActionResult<IEnumerable<Sach>>> SearchByMaDangKy(string maDangKy)
        {
            // Tìm kiếm sách gần đúng với mã đăng ký sách
            var sachList = await _context.Saches
                .Where(s => EF.Functions.Like(s.Sach1, $"%{maDangKy}%"))
                .ToListAsync();

            if (sachList == null || !sachList.Any())
            {               
                return NotFound();
            }

            return sachList;
        }
         [HttpPost]
        public async Task<ActionResult<Sach>> CreateSach(Sach sach)
        {
            // Thêm sách mới vào cơ sở dữ liệu
            _context.Saches.Add(sach);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetSachById), new { id = sach.Sach1 }, sach);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Sach>> GetSachById(string id)
        {
            // Tìm sách theo ID
            var sach = await _context.Saches.FindAsync(id);

            if (sach == null)
            {
                return NotFound();
            }

            return sach;
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSach(string id)
        {
            // Tìm sách theo ID
            var sach = await _context.Saches.FindAsync(id);
            if (sach == null)
            {
                return NotFound();
            }

            // Xóa sách khỏi cơ sở dữ liệu
            _context.Saches.Remove(sach);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpPut("{id}")] //cap nhap 1 cuon sach 
        public async Task<IActionResult> UpdateSach(string id, Sach sach)
        {
            if (id != sach.Sach1)
            {
                return BadRequest();
            }

            _context.Entry(sach).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SachExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool SachExists(string id)
        {
            return _context.Saches.Any(e => e.Sach1 == id);
        }

    }
}

    



