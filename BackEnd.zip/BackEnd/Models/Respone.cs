using System;
using System.Collections.Generic;
using BackEnd.Entities;
namespace BackEnd.Models
{
    public class Respone
    {
    public int Statuscode {get; set;}
    public string StatusMessage {get; set;}
    public List<Sach>lstsach {get; set;}
        

    }

}