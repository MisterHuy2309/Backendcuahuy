using System;
using System.Collections.Generic;
using System.Data;
using BackEnd.Entities;
using  Microsoft.Data.SqlClient;
namespace BackEnd.Models
{
    public class DAL
    {
        public Respone GetAllSach(SqlConnection sqlconn )
        {
            Respone rspn = new Respone();
            SqlDataAdapter da = new SqlDataAdapter("spAPI_Sach_GetAll",sqlconn);
            DataTable dt = new DataTable();
            List<Sach>lstsach = new List<Sach>();
            da.Fill(dt);
            if (dt.Rows.Count >0)
            {
                for(int i = 0; i<dt.Rows.Count; i++)
                {
                    Sach s = new Sach();
                    s.Sach1 = Convert.ToString(dt.Rows[i]["SACH"]);
                     s.Nhaxuatban = Convert.ToString(dt.Rows[i]["NhaXuatBan"]);
                      s.Tensach = Convert.ToString(dt.Rows[i]["TenSach"]);
                       s.Sotrang = Convert.ToString(dt.Rows[i]["SoTrang"]);
                        s.Tinhtrang = Convert.ToString(dt.Rows[i]["TinhTrang"]);
                        lstsach.Add(s);
                }

            }
            if(lstsach.Count > 0)
            {
                rspn.Statuscode = 200;
                rspn.StatusMessage = "Ok";
                rspn.lstsach = lstsach;
            }
            else
            {
                rspn.Statuscode = 200;
                rspn.StatusMessage = "No data found";
                rspn.lstsach = null;
            }
            return rspn;
        }
    }
}
   