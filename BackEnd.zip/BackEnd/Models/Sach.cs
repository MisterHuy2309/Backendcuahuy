using System;
using System.Collections.Generic;
namespace BackEnd.Models
{
    public class SachVM
    {
        public string Sach {get ; set;} = null!;
        public string NhaXuatBan {get ; set;}  = null!;
        public string TenSach {get ; set;}  = null!;
        public string SoTrang {get ; set;}  = null!;
        public string TinhTrang {get ; set;}  = null!;

    }
}